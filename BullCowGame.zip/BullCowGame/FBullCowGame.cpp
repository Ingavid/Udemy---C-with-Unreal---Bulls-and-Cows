#include "stdafx.h"
#include <iostream>
#include <cctype>
#include <algorithm>
#include "FBullCowGame.h"
#include <map>
#define TMap std::map

using FString = std::string;
using int32 = int;

FBullCowGame::FBullCowGame(){ Reset(); }

int32 FBullCowGame::GetMaxTries() const { return MyMaxTries; }
int32 FBullCowGame::GetCurrentTry() const { return MyCurrentTry; }
int32 FBullCowGame::GetHiddenWordLength() const { return MyHiddenWord.length(); }
bool FBullCowGame::IsGameWon() const { return bGameIsWon; }
bool FBullCowGame::HasPlayedBefore() const { return bPlayedBefore; }

void FBullCowGame::Reset()
{
	constexpr int32 MAX_TRIES = 8;
	const FString HIDDEN_WORD = "artful";

	MyMaxTries = MAX_TRIES;
	MyCurrentTry = 1;
	MyHiddenWord = HIDDEN_WORD;
	bGameIsWon = false;
	return;	
}

void FBullCowGame::GameIsWon() //Set the game state to won
{
	bGameIsWon = true;
}


void FBullCowGame::GameNotWon() //Reset the game state to not won
{
	bGameIsWon = false;
}



bool FBullCowGame::IsGuessIsogram(FString Guess) const
{
	if (Guess.length() < 2) { return true; }	//Treat 0- and 1-letter words as isograms 
	
	TMap<char, bool> LetterSeen; //Set up our TMap
	for (auto Letter : Guess)
	{
		Letter = tolower(Letter);	//Handle mixed case
		if (LetterSeen[Letter])//	If the letter is in the map
			return false;	//	We do not have an isogram
		else if (!LetterSeen[Letter])	//	If the letter is not in the map
			LetterSeen[Letter] = true;	//	Add it to map
	}
	
	return true;
}

//TODO write richer return value, write code so that the function has a basis upon which to decide whether or not a given answer is valid.
EGuessStatus FBullCowGame::CheckGuessValidity(FString Guess) const
{
	int32 GuessLength = Guess.length();
	
	if (!IsGuessIsogram(Guess))	//if the guess isn't an isogram
	{
		return EGuessStatus::Not_Isogram;	//TODO write function to return error
	}
	else if (!IsGuessLowercase(Guess))	//if the guess is all or part uppercase or contains other characters
	{
		return EGuessStatus::Not_Lowercase;	//return an error
	}
	else if (GuessLength != GetHiddenWordLength())	//if the guess is the wrong length
	{
		return EGuessStatus::Wrong_Length;	//TODO write function to return error
	}
	else	//otherwise
	{
		return EGuessStatus::OK;	//return an 'okiedokie' //The guess is valid and the program should accept it
	}
}


bool FBullCowGame::IsGuessLowercase(FString Guess) const	//Check if the guess string contains only alphabetical characters
{
	if (Guess.length() <= 1) {
		return true;
	}

	for (auto GLetter : Guess) //loop, iterating selection of the characters in 'Guess' and check if they're lowercase
	{
		if (!islower(GLetter)) {	//check if the character in the guess is lowercase
			return false;
		}
	}
	return true;
}

//Counts bulls and cows as well as increasing try no., providing the guess is valid.
FBullCowCount FBullCowGame::SubmitValidGuess(FString Guess)
{
	MyCurrentTry++;
	FBullCowCount BullCowCount;
	int32 WordLength = MyHiddenWord.length(); //assuming the guess is valid

	//loop through all the letters in the guess
	for (int32 GChar = 0; GChar < WordLength; GChar++) 
	{  //compare letters against the hidden word, to see if they're the same
		for (int32 MHWChar = 0; MHWChar < WordLength; MHWChar++)
		{
			//check if the current character - from Guess - is the same symbol as the one from MyHiddenWord
			if (Guess[GChar] == MyHiddenWord[MHWChar])
			{
				if (GChar == MHWChar) 
				{
					BullCowCount.Bulls++;
				} 
				else if (GChar != MHWChar)
				{ //If they're not in the same place
					BullCowCount.Cows++; //Increment cows
				}

			}
		}
	}

	return BullCowCount;
}

void FBullCowGame::PrintGameSummary(FBullCowCount BullCowCount)
{
	if (bGameIsWon == true)
	{
		std::cout << "Congratulations! You win!!!\n";
		if (GetCurrentTry() == 2) {
			std::cout << "You only used " << GetCurrentTry() - 1 << " try!\n\n";
		}
		else
		{
			std::cout << "You used " << GetCurrentTry() - 1 << " tries\n\n";
		}
	}
	else
	{
		std::cout << "You used all " << GetCurrentTry() - 1 << " tries\n\n";
		std::cout << "You lose!\n" << "Better luck next time!\n";
	}
	
	bPlayedBefore = true;
	return;
}
