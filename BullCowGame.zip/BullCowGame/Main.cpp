// Main.cpp : Defines the entry point for the console application.
//
/* This is the console executable that makes use of the BullCow class.
This acts as the view in an MVC pattern and is responsible for all
user interactions.
For game logic, see the FBullCowGame class.
*/

#include "stdafx.h"
#include <iostream>
#include <string>
#include <cctype>
#include <cstring>
#include <stdio.h>
#include "FBullCowGame.h"


using int32 = int;
using FText = std::string;

	void PrintIntro();
	FText GetValidGuess();
	void PlayGame();
	bool AskToPlayAgain();
	bool IsStringAlpha(FText);		//When the user is asked if they want to play again, check their answer to make sure it's all alphabet and not numbers or spaces.
	

FBullCowGame BCGame;	//Instantiate a new game

//TODO Draw a cute little graphic when the game begins
//TODO have the program understand and respond to a valid guess
int main()
{

	bool bPlayAgain = false;
	do {
		PrintIntro();
		PlayGame();
		bPlayAgain = AskToPlayAgain();
	} while (bPlayAgain);
	return 0;
}

//Introduce the program
//TODO choose an isogram
//TODO change 'WORD_LENGTH' based on the number of characters within it
void PrintIntro()
{
	if (BCGame.HasPlayedBefore() == true)
	{
		std::cout << "\n\n";
	}
	
	std::cout << "Welcome to Bulls and Cows";
	std::cout << std::endl;
	std::cout << "Can you guess the " << BCGame.GetHiddenWordLength();
	std::cout << "-letter isogram I'm thinking of?" << std::endl;
	std::cout << std::endl;
	return;
}

void PlayGame()
{
	BCGame.Reset();

	int32 MaxTries = BCGame.GetMaxTries();
	FBullCowCount BullCowCount;


	//TODO change to a while loop
	//ask questions while the game is NOT won and while there are tries remaining
	while(!BCGame.IsGameWon() && BCGame.GetCurrentTry() <= MaxTries)
	{

		std::cout << "Go on...\n\n";
		FText Guess = GetValidGuess();

		//submit valid guess to the game
		BullCowCount = BCGame.SubmitValidGuess(Guess);

		if (BullCowCount.Bulls == BCGame.GetHiddenWordLength())
		{
			BCGame.GameIsWon();
		}

		if (!BCGame.IsGameWon())
		{
			std::cout << "Bulls = " << BullCowCount.Bulls;
			std::cout << ". Cows = " << BullCowCount.Cows << std::endl;
			std::cout << "\n";
		}
	}
	BCGame.PrintGameSummary(BullCowCount);
	return;
}

bool AskToPlayAgain()
{
	FText Response = "";
	std::cout << "Would you like to play again with the same hidden word?" << std::endl;
	getline(std::cin, Response);
	while (IsStringAlpha(Response) == false) {
			std::cout << "Would you like to play again? (Y/N)" << std::endl;
			getline(std::cin, Response);
		}

	return (Response[0] == 'y') || (Response[0] == 'Y');
}

bool IsStringAlpha(FText String)		/*Check each character of the user's response, in sequence, to see if it's alphabetic. 
										Code returns false if it discovers anything that's not a letter.*/
{
	for (int charCheckNum = 0; charCheckNum < String.length() -1; charCheckNum++)
	{
		if (!std::isalpha(String[charCheckNum])) {
			return false;
		}	
	}
	return true;
}

//loop until the user makes a valid guess
FText GetValidGuess()
{
	EGuessStatus Status = EGuessStatus::Invalid_Status;
	FText Guess = "";
	do
	{
		int32 CurrentTry = BCGame.GetCurrentTry();
		std::cout << "It's try " << CurrentTry << std::endl;
		std::cout << "Take your guess: ";
		getline(std::cin, Guess);

		Status = BCGame.CheckGuessValidity(Guess);
		switch (Status)
		{
		case EGuessStatus::Wrong_Length:
			std::cout << "Please enter a " << BCGame.GetHiddenWordLength() << "-letter word.\n";
			break;
		case EGuessStatus::Not_Lowercase:
			std::cout << "That guess is not the right case. Try using lowercase letters.\n";
			break;
		case EGuessStatus::Not_Isogram:
			std::cout << "Please enter an isogram. Make a guess with letters that are all different from each other.\n";
			break;
		default:
			break;
		}
		std::cout << std::endl;
	} while (Status != EGuessStatus::OK);
	return Guess;
}