#pragma once
#include <string>

using int32 = int;
using FString = std::string;

//Two integers, initialised to 0
struct FBullCowCount
{
	int32 Bulls = 0;
	int32 Cows = 0;
};

enum class EGuessStatus
{
	Invalid_Status,
	OK,
	Not_Isogram,
	Not_Lowercase,

	Wrong_Length,
	Not_A_Word, //When the guess is not made of letters or when it's not in the game's dictionary
	Already_Said_That

};

class FBullCowGame {
public:
	FBullCowGame(); //constructor

	int32 GetMaxTries() const;
	int32 GetCurrentTry() const;
	int32 GetHiddenWordLength() const;
	bool IsGameWon() const;
	bool HasPlayedBefore() const;

	EGuessStatus CheckGuessValidity(FString) const; //TODO create richer return value

	void PrintGameSummary(FBullCowCount);
	void Reset(); //TODO: Make a more rich return value
	void GameIsWon(); //Set Game to won
	void GameNotWon(); //Set game win state not won
	FBullCowCount SubmitValidGuess(FString);
	bool IsGuessLowercase(FString Guess) const;


private:
	//See the constructor for initialisation.
	int32 MyCurrentTry;
	int32 MyMaxTries;
	FString MyHiddenWord;
	bool bGameIsWon = false;
	bool bPlayedBefore = false;

	bool IsGuessIsogram(FString) const;

};